AEP Downgrader - Linux Portable Version

To run the application:
1. Make sure you have Python and PyQt5 installed on your system
2. Or run the executable directly: ./AEP-Downgrader

Alternatively, you can use the launcher script:
./start_AEP-Downgrader.sh

The application allows you to convert Adobe After Effects projects 
from newer versions to older ones.
